// Copy this file to shared/config.js (git-ignored) and fill in your values.
// Only the anon (public) key belongs here.
export const SUPABASE_URL = "https://YOUR-PROJECT.supabase.co";
export const SUPABASE_ANON_KEY = "YOUR-ANON-KEY";
