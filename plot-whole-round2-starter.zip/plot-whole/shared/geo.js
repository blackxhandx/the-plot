// Distance helpers (no libraries). Mirrors what PostGIS ST_DWithin does in the database.
const R = 6371008.8; // mean Earth radius in metres
const rad = (d) => (d * Math.PI) / 180;

export function haversineMeters(lat1, lng1, lat2, lng2) {
  const dLat = rad(lat2 - lat1);
  const dLng = rad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(rad(lat1)) * Math.cos(rad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

export function withinMeters(a, b, meters) {
  return haversineMeters(a.lat, a.lng, b.lat, b.lng) <= meters;
}
