// PLOT WHOLE priority score (0-100). INITIAL ASSUMPTIONS - tune after talking to an officer.
// Must stay in sync with compute_priority() in supabase/schema.sql.
export const SEVERITY_POINTS = { low: 10, medium: 25, dangerous: 40 };
export const LOCATION_POINTS = { local: 5, arterial: 15, main: 20, school_hospital: 25 };
export const WAIT_MAX_DAYS = 14;
export const WAIT_MAX_POINTS = 20;
export const CONFIRM_CAP = 5;
export const CONFIRM_POINTS_EACH = 3; // cap = 15 points, so "Me Too" can never dominate

export function computePriority({ severity, roadType, daysWaiting, confirmations }) {
  const sev = SEVERITY_POINTS[severity] ?? SEVERITY_POINTS.medium;
  const loc = LOCATION_POINTS[roadType] ?? LOCATION_POINTS.local;
  const wait = (Math.min(Math.max(daysWaiting, 0), WAIT_MAX_DAYS) / WAIT_MAX_DAYS) * WAIT_MAX_POINTS;
  const conf = Math.min(Math.max(confirmations, 0), CONFIRM_CAP) * CONFIRM_POINTS_EACH;
  return Math.round((sev + loc + wait + conf) * 10) / 10;
}

// Label cut-offs are our own assumption, not a standard.
export function priorityLabel(score) {
  if (score >= 70) return "Critical";
  if (score >= 50) return "High";
  if (score >= 30) return "Medium";
  return "Low";
}
