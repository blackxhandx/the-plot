import assert from "node:assert/strict";
import { haversineMeters, withinMeters } from "./geo.js";
import { computePriority, priorityLabel } from "./priority.js";
import { isRepeatFailure, isChronic } from "./flags.js";

// Worked examples from the deck (slide 5)
assert.equal(computePriority({ severity: "dangerous", roadType: "school_hospital", daysWaiting: 7, confirmations: 3 }), 84);
assert.equal(computePriority({ severity: "low", roadType: "local", daysWaiting: 7, confirmations: 0 }), 25);
// "Me Too" is capped at 15 points
assert.equal(
  computePriority({ severity: "low", roadType: "local", daysWaiting: 0, confirmations: 50 }) -
    computePriority({ severity: "low", roadType: "local", daysWaiting: 0, confirmations: 0 }),
  15
);
// Waiting is capped at 14 days
assert.equal(
  computePriority({ severity: "low", roadType: "local", daysWaiting: 400, confirmations: 0 }),
  computePriority({ severity: "low", roadType: "local", daysWaiting: 14, confirmations: 0 })
);
assert.equal(priorityLabel(84), "Critical");
assert.equal(priorityLabel(25), "Low");

// Geo: 0.0001 deg latitude is about 11.1 m
const d = haversineMeters(13.0, 80.0, 13.0001, 80.0);
assert.ok(d > 10.5 && d < 11.7, `unexpected distance ${d}`);
assert.ok(withinMeters({ lat: 13.0, lng: 80.0 }, { lat: 13.0001, lng: 80.0 }, 20));
assert.ok(!withinMeters({ lat: 13.0, lng: 80.0 }, { lat: 13.0003, lng: 80.0 }, 20)); // ~33 m

// Flags
const now = new Date("2026-10-10T00:00:00Z");
const daysAgo = (n) => new Date(now - n * 86400000);
const prev = { id: "a", lat: 13.0, lng: 80.0, createdAt: daysAgo(100), closedAt: daysAgo(30) };
const again = { id: "b", lat: 13.00005, lng: 80.0, createdAt: daysAgo(10), closedAt: null };
const farAway = { id: "c", lat: 13.001, lng: 80.0, createdAt: daysAgo(10), closedAt: null };
assert.ok(isRepeatFailure(again, [prev]));
assert.ok(!isRepeatFailure(farAway, [prev]), "a pothole far away is not a repeat");
assert.ok(!isRepeatFailure({ ...again, createdAt: daysAgo(-40) }, [prev]), "repeat window is 60 days");
const third = { id: "e", lat: 13.0, lng: 80.00001, createdAt: daysAgo(150), closedAt: null };
const tooOld = { id: "o", lat: 13.0, lng: 80.0, createdAt: daysAgo(300), closedAt: daysAgo(290) };
assert.ok(isChronic(again, [prev, again, third], now));
assert.ok(!isChronic(again, [prev, again], now), "two incidents are not chronic");
assert.ok(!isChronic(again, [tooOld, again, prev], now), "incidents older than 180 days do not count");

console.log("All groundwork tests passed.");
