// Repeat-failure and chronic-location rules. INITIAL ASSUMPTIONS to validate with an officer.
// Report counts alone never create either flag - only distinct incidents do.
import { withinMeters } from "./geo.js";

export const RULES = { radiusM: 20, repeatDays: 60, chronicDays: 180, chronicMin: 3 };
const DAY = 86400000;

// incident = { id, lat, lng, createdAt: Date, closedAt: Date|null }
export function isRepeatFailure(incident, closedIncidents, rules = RULES) {
  return closedIncidents.some(
    (c) =>
      c.id !== incident.id &&
      c.closedAt &&
      c.closedAt <= incident.createdAt &&
      incident.createdAt - c.closedAt <= rules.repeatDays * DAY &&
      withinMeters(incident, c, rules.radiusM)
  );
}

export function isChronic(incident, allIncidents, now = new Date(), rules = RULES) {
  const recent = allIncidents.filter(
    (o) => now - o.createdAt <= rules.chronicDays * DAY && withinMeters(incident, o, rules.radiusM)
  );
  return recent.length >= rules.chronicMin;
}
