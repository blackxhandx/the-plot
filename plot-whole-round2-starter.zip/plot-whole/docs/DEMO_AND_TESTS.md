# Demo flow, acceptance checks and evidence

## Demo flow (target: under 3 minutes)
1. Citizen creates a report (photo, GPS, severity) > complaint ID appears.
2. Refresh the page > the ticket is still there (saved on the server).
3. A second report appears nearby > officer sees the duplicate suggestion > **confirms link**.
4. Another nearby report that is a different pothole > officer **splits** it.
5. Queue is ordered by priority score; open the score breakdown.
6. Officer assigns, moves to In progress, uploads the after-photo, closes.
7. Analytics: heatmap, a repeat failure and a chronic location from sample data.
8. (If built) citizen answers "Is it fixed?" > two "not fixed" answers send the job back for review.

Say clearly: sample data is labelled; thresholds are initial assumptions; no measured results.

## Acceptance checks (write these first, tick them at the end)
- [ ] Ticket still exists after refresh
- [ ] GPS denied > manual location works
- [ ] Failed upload > retry without losing the form
- [ ] A second report near an open pothole is suggested as a duplicate
- [ ] Two separate nearby potholes can stay separate (officer split)
- [ ] A citizen cannot change an incident status (try it through the API)
- [ ] Closing without an after-photo is refused
- [ ] A new incident near a recently closed repair shows as a repeat failure

## Evidence to prepare
- [ ] README with setup steps and `.env.example`
- [ ] Labelled sample data
- [ ] Screenshots of the working screens
- [ ] Clean commit history from all three teammates
- [ ] Demo video (backup in case the venue network fails)
- [ ] A small set of volunteer task tests and one officer or resident conversation (only claim what you actually did)
