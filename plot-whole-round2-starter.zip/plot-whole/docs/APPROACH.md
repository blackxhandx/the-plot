# Our approach to PS15 (read before Round 2)

## The problem in one paragraph
Pothole complaints are scattered. Citizens report the same pothole again and again and never see what happens next. Officials cannot tell duplicate reports from genuinely recurring damage, or explain why one repair comes first. PLOT WHOLE gives every pothole one shared record from first report to verified repair.

## Our idea in six lines
1. A citizen reports in seconds: photo, GPS (pin can be dragged), severity. They get a complaint ID and a status timeline.
2. Reports within about 20 m are **suggested** as duplicates; an officer **confirms or splits**. Many reports become one incident, separate potholes stay separate.
3. Nearby users tap **Me Too**. It adds a capped amount to priority, so popular areas cannot jump the queue.
4. Officers see a **transparent priority score**, assign work, update status, and cannot close a job without an after-repair photo. Every change is logged.
5. **Repeat failure** (new damage near a recently closed repair) is separated from **chronic location** (3+ incidents). Report counts alone never create either flag.
6. Analytics: heatmap, repeat vs chronic list, repair-time view.

## The rules (initial assumptions)
- Priority (0-100) = severity (10/25/40) + location (local 5, arterial 15, main 20, school/hospital 25) + waiting (min(days,14)/14 x 20) + Me Too (min(n,5) x 3).
- Worked examples: dangerous + near school + 7 days + 3 confirmations = 84; low + local + 7 days + 0 = 25.
- Repeat failure: new incident within 20 m and 60 days after a closed repair. Chronic: 3+ incidents within 20 m in 180 days.
- Statuses: Reported > Verified > Assigned > In progress > Repaired > Closed (or sent back for review).

## Core MVP vs if time allows
**Core:** report with photo + GPS + severity, complaint ID + timeline, Me Too, duplicate suggestion with officer confirm/split, priority queue, assign, status log, photo-required closure, heatmap, repeat vs chronic.
**If time allows:** citizen "Is it fixed?" check (two "not fixed" answers send the job back for review), SLA alerts, repair-time and reopen-rate stats, public ward scoreboard.

## Build order (scale to the real hours you get)
1. **Foundation:** repo, Supabase project, schema and seed run without errors. Pages load and read sample data.
2. **Core loop:** submit a report > see it in the officer queue > assign > upload after-photo > close.
3. **Smart parts:** duplicate suggestion flow, priority ordering, repeat/chronic flags.
4. **Analytics:** heatmap and the repeat vs chronic list.
5. **If time allows:** Is-it-fixed check, SLA alerts, scoreboard.
6. **Last hour:** freeze features, run the acceptance checks, record a demo video, fix only bugs.
Cut line: if behind schedule, drop everything under "if time allows" first, then the heatmap.

## Risks and fallbacks
| Risk | Fallback |
|---|---|
| GPS denied or inaccurate | Draggable pin and manual placement |
| Weak Wi-Fi at the venue | Test on mobile data; keep sample data ready; record a backup demo video |
| Supabase setup trouble | Run schema on day zero; keep `shared/*.js` rules working with a local mock |
| Merge conflicts | One folder per person, small pull requests |
| Running out of time | Follow the cut line above |

## What we will not claim
No measured results, no real users, no tested accuracy. Sample data is labelled as sample. All thresholds are assumptions we want to validate with an officer.

## Questions to ask organisers or mentors on the day
- What are the official judging criteria and weights?
- Is any real or sample complaint data available?
- Are there rules on libraries, hosting or databases?
- How long is the demo slot, and what must be live versus recorded?

## Our 60-second pitch (practise it)
"Potholes get reported again and again, but nobody can see what happened to a complaint, and officials cannot tell a duplicate from a pothole that keeps coming back. PLOT WHOLE gives each pothole one record: citizens report with a photo and GPS, officers confirm duplicates, a transparent score ranks the queue, a repair cannot be closed without an after-photo, and the analytics separate repeat failures from chronic locations. We are showing a working prototype with labelled sample data, and every rule is a configurable assumption we want to validate with an officer."
