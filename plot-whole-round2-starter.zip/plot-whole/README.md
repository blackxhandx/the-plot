# PLOT WHOLE

Smart pothole reporting and tracking (PS15) - Team Git Happens.
One pothole, one shared record: from first report to verified repair, with repeat failures remembered.

> Status: **Round 2 groundwork**. The rule modules and tests run. The SQL has been written but **not yet run against a live Supabase project** - do that first (see "Day-zero setup").

## What is in this kit

| Path | What it is |
|---|---|
| `docs/APPROACH.md` | Our ideas, plan and approach (read this before Round 2) |
| `docs/DEMO_AND_TESTS.md` | Demo flow, acceptance checks, evidence checklist |
| `supabase/schema.sql` | Tables, PostGIS rules, officer actions, views, row-level security, photo bucket |
| `supabase/seed.sql` | Labelled sample data (chronic spot, repeat failure, duplicate suggestion) |
| `shared/geo.js`, `priority.js`, `flags.js` | The same rules in JavaScript (distance, priority score, repeat/chronic) |
| `shared/test.js` | Tests for those rules (`npm test`) |
| `citizen/`, `dashboard/`, `analytics/` | One folder per teammate (empty on purpose) |

## Day-zero setup (about 30 minutes, do it before Round 2)

1. **Repo:** create a GitHub repo, push this folder, and give all three teammates access.
2. **Supabase:** create a free project. In *Authentication > Providers* turn on **Allow anonymous sign-ins** (lets citizens report without an account).
3. **Database:** open *SQL Editor*, paste `supabase/schema.sql`, run it. Read any error and fix it now, not during the event. Then run `supabase/seed.sql`.
4. **Officer account:** sign up one test user, then run `update profiles set role = 'officer' where id = '<that user id>';`
5. **Keys:** copy `shared/config.example.js` to `shared/config.js` and paste your project URL and **anon** key. Never commit the `service_role` key.
6. **Local run:** `npm test` (rules), then `npx serve .` to preview pages.
7. **Phone test:** open the served page on a real phone to confirm GPS permission and camera upload work over HTTPS (GitHub Pages or Netlify give you HTTPS).

## Who builds what (from our short description)

| Teammate | Folder | Owns |
|---|---|---|
| R. Ragav | `citizen/` | Report form, GPS and draggable pin, photo upload with retry, complaint tracker, citizen map |
| M. Avinaash | `dashboard/` | Priority queue, duplicate suggestions (confirm or split), assign, status log, closure rules |
| S. Deepak Raghavendra | `analytics/` + `supabase/` | Schema, row-level security, recurrence rules, heatmap, repair-time stats, integration |

Rule: edit only your own folder. If you need a change in `shared/` or `supabase/`, ask the owner.

## Git workflow

- Branches: `feature/citizen`, `feature/dashboard`, `feature/analytics`. Open a pull request into `main`; another teammate reviews.
- Small commits with clear messages (`add photo upload retry`, not `update`).
- Never commit `.env` or `shared/config.js`.

## Assumptions (all initial, to validate with an officer)

20 m duplicate and recurrence radius, 60-day repeat window, 180-day chronic window, and the priority weights in `shared/priority.js`. The SQL and JavaScript must always use the same numbers.
