-- =====================================================================
-- PLOT WHOLE - SAMPLE DATA (run AFTER schema.sql)
--
-- Everything inserted here is labelled is_sample = true and the wards are named
-- "(sample)". Show it as sample data in the demo; never present it as real results.
--
-- REPLACE the base point below with the centre of your pilot ward (lng, lat).
-- Confirmations ("Me Too") are not seeded because they need real user accounts.
-- =====================================================================

do $$
declare
  base geography := ST_SetSRID(ST_MakePoint(80.2707, 13.0827), 4326)::geography;  -- placeholder
  spot geography;
  low_loc geography;
  c1 uuid; c2 uuid; c3 uuid;
  school uuid; main1 uuid; low1 uuid; prog uuid; done1 uuid;
begin
  -- 1) CHRONIC SPOT: three incidents within 20 m over about five months.
  --    The third one is a repeat failure of the second (opened within 60 days of its closure).
  spot := ST_Project(base, 300, radians(40));

  insert into incidents (location, ward, road_type, severity_citizen, status, created_at, updated_at, closed_at, is_sample)
  values (spot, 'Ward A (sample)', 'arterial', 'medium', 'closed',
          now() - interval '150 days', now() - interval '140 days', now() - interval '140 days', true)
  returning id into c1;

  insert into incidents (location, ward, road_type, severity_citizen, status, created_at, updated_at, closed_at, is_sample)
  values (ST_Project(spot, 6, 0), 'Ward A (sample)', 'arterial', 'dangerous', 'closed',
          now() - interval '100 days', now() - interval '30 days', now() - interval '30 days', true)
  returning id into c2;

  insert into incidents (location, ward, road_type, severity_citizen, status, repeat_of, created_at, is_sample)
  values (ST_Project(spot, 12, radians(90)), 'Ward A (sample)', 'arterial', 'dangerous', 'reported',
          c2, now() - interval '10 days', true)
  returning id into c3;

  insert into repairs (incident_id, completed_at, after_photo_path, notes) values
    (c1, now() - interval '140 days', 'sample/after-1.jpg', 'Sample repair record'),
    (c2, now() - interval '30 days',  'sample/after-2.jpg', 'Sample repair record');

  -- 2) Other incidents at different priorities and stages.
  insert into incidents (location, ward, road_type, severity_citizen, severity_confirmed, status, created_at, is_sample)
  values (ST_Project(base, 150, radians(200)), 'Ward A (sample)', 'school_hospital', 'dangerous', 'dangerous', 'verified',
          now() - interval '7 days', true)
  returning id into school;

  insert into incidents (location, ward, road_type, severity_citizen, status, created_at, is_sample)
  values (ST_Project(base, 220, radians(90)), 'Ward B (sample)', 'main', 'medium', 'assigned',
          now() - interval '12 days', true)
  returning id into main1;

  low_loc := ST_Project(base, 400, radians(270));
  insert into incidents (location, ward, road_type, severity_citizen, status, created_at, is_sample)
  values (low_loc, 'Ward B (sample)', 'local', 'low', 'reported', now() - interval '2 days', true)
  returning id into low1;

  insert into incidents (location, ward, road_type, severity_citizen, status, created_at, is_sample)
  values (ST_Project(base, 520, radians(320)), 'Ward B (sample)', 'arterial', 'dangerous', 'in_progress',
          now() - interval '5 days', true)
  returning id into prog;

  insert into incidents (location, ward, road_type, severity_citizen, status, created_at, updated_at, closed_at, is_sample)
  values (ST_Project(base, 600, radians(150)), 'Ward B (sample)', 'local', 'medium', 'closed',
          now() - interval '35 days', now() - interval '20 days', now() - interval '20 days', true)
  returning id into done1;
  insert into repairs (incident_id, completed_at, after_photo_path, notes)
  values (done1, now() - interval '20 days', 'sample/after-3.jpg', 'Sample repair record');

  -- 3) Reports. Two reports are already linked to the school incident ("many reports, one incident").
  insert into reports (location, severity, incident_id, is_sample) values
    (ST_Project(base, 150, radians(200)), 'dangerous', school, true),
    (ST_Project(ST_Project(base, 150, radians(200)), 4, 0), 'dangerous', school, true),
    (ST_Project(base, 220, radians(90)), 'medium', main1, true),
    (low_loc, 'low', low1, true);

  -- This one has NO incident, so the trigger suggests low1 as a duplicate (about 12 m away).
  -- Use it to demo the officer "confirm link / split" action.
  insert into reports (location, severity, is_sample)
  values (ST_Project(low_loc, 12, 0), 'low', true);
end;
$$;

-- Quick check: expect 8 incidents, 5 reports, 1 report waiting for an officer decision.
select (select count(*) from incidents where is_sample) as sample_incidents,
       (select count(*) from reports   where is_sample) as sample_reports,
       (select count(*) from reports   where is_sample and incident_id is null) as awaiting_officer;
