-- =====================================================================
-- PLOT WHOLE - Supabase schema (Postgres + PostGIS)
-- Run this whole file once in Supabase > SQL Editor.
--
-- STATUS: written for the Round 2 groundwork. It has NOT been run against a
-- live Supabase project yet. Run it early, read any error message, and fix it
-- before building on it.
--
-- All distances, weights and time windows are INITIAL ASSUMPTIONS
-- (20 m radius, 60-day repeat window, 180-day chronic window, priority weights).
-- Keep them in sync with shared/priority.js and shared/flags.js.
-- =====================================================================

create extension if not exists postgis;

-- ---------------------------------------------------------------- tables

create table if not exists profiles (
  id           uuid primary key references auth.users(id) on delete cascade,
  role         text not null default 'citizen' check (role in ('citizen', 'officer', 'admin')),
  display_name text,
  created_at   timestamptz not null default now()
);

-- One row per real-world pothole ("incident"). Many reports can point to one incident.
create table if not exists incidents (
  id                 uuid primary key default gen_random_uuid(),
  location           geography(Point, 4326) not null,
  ward               text,
  road_type          text not null default 'local'
                       check (road_type in ('local', 'arterial', 'main', 'school_hospital')),
  severity_citizen   text not null default 'medium' check (severity_citizen in ('low', 'medium', 'dangerous')),
  severity_confirmed text check (severity_confirmed in ('low', 'medium', 'dangerous')),
  status             text not null default 'reported'
                       check (status in ('reported', 'verified', 'assigned', 'in_progress', 'repaired', 'closed', 'review')),
  assigned_to        uuid references profiles(id),
  repeat_of          uuid references incidents(id),   -- earlier closed incident this one repeats
  is_sample          boolean not null default false,  -- label demo data honestly
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now(),
  closed_at          timestamptz
);
create index if not exists incidents_location_gix on incidents using gist (location);
create index if not exists incidents_status_idx   on incidents (status);

-- One row per citizen submission.
create table if not exists reports (
  id                    uuid primary key default gen_random_uuid(),
  complaint_no          text unique,
  reporter_id           uuid references profiles(id) default auth.uid(),
  location              geography(Point, 4326) not null,
  photo_path            text,                          -- path inside the private 'photos' bucket
  severity              text not null default 'medium' check (severity in ('low', 'medium', 'dangerous')),
  note                  text,
  incident_id           uuid references incidents(id), -- null while an officer decides on a duplicate
  suggested_incident_id uuid references incidents(id), -- nearby open incident (officer confirms or splits)
  is_sample             boolean not null default false,
  created_at            timestamptz not null default now()
);
create index if not exists reports_location_gix on reports using gist (location);

-- "Me Too" confirmations (one per user per incident).
create table if not exists confirmations (
  id          bigint generated always as identity primary key,
  incident_id uuid not null references incidents(id) on delete cascade,
  user_id     uuid not null default auth.uid() references profiles(id),
  created_at  timestamptz not null default now(),
  unique (incident_id, user_id)
);

create table if not exists repairs (
  id               uuid primary key default gen_random_uuid(),
  incident_id      uuid not null references incidents(id) on delete cascade,
  started_at       timestamptz,
  completed_at     timestamptz,
  after_photo_path text,
  notes            text
);

-- Every status change is logged here.
create table if not exists status_events (
  id          bigint generated always as identity primary key,
  incident_id uuid not null references incidents(id) on delete cascade,
  actor_id    uuid,
  from_status text,
  to_status   text not null,
  note        text,
  created_at  timestamptz not null default now()
);

-- IF TIME ALLOWS: citizen "Is it fixed?" answers.
create table if not exists fix_checks (
  id          bigint generated always as identity primary key,
  incident_id uuid not null references incidents(id) on delete cascade,
  user_id     uuid not null default auth.uid() references profiles(id),
  answer      text not null check (answer in ('fixed', 'not_fixed')),
  created_at  timestamptz not null default now(),
  unique (incident_id, user_id)
);

-- ---------------------------------------------------------------- helpers

create or replace function is_officer() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and role in ('officer', 'admin'));
$$;

-- Create a profile row automatically for every new auth user.
create or replace function handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id) values (new.id) on conflict do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function handle_new_user();

create or replace function generate_complaint_no() returns text
language sql volatile as $$
  select 'PW-' || to_char(now(), 'YYMMDD') || '-' || upper(substr(md5(random()::text || clock_timestamp()::text), 1, 4));
$$;

-- ---------------------------------------------------------------- rules

-- Nearest OPEN incident within p_radius_m metres (duplicate SUGGESTION, officer confirms).
create or replace function suggest_duplicate(p_loc geography, p_radius_m numeric default 20) returns uuid
language sql stable as $$
  select id from incidents
  where status <> 'closed' and ST_DWithin(location, p_loc, p_radius_m)
  order by ST_Distance(location, p_loc)
  limit 1;
$$;

-- Most recent CLOSED incident nearby, closed within p_days (repeat failure).
create or replace function find_recent_closed(p_loc geography, p_radius_m numeric default 20, p_days int default 60) returns uuid
language sql stable as $$
  select id from incidents
  where status = 'closed'
    and closed_at > now() - make_interval(days => p_days)
    and ST_DWithin(location, p_loc, p_radius_m)
  order by closed_at desc
  limit 1;
$$;

-- Priority score 0-100:  severity (10/25/40) + location (5/15/20/25)
--                        + waiting (min(days,14)/14 x 20) + Me Too (min(n,5) x 3)
create or replace function compute_priority(p_incident uuid) returns numeric
language sql stable as $$
  select
    (case coalesce(i.severity_confirmed, i.severity_citizen)
       when 'low' then 10 when 'medium' then 25 else 40 end)
  + (case i.road_type
       when 'school_hospital' then 25 when 'main' then 20 when 'arterial' then 15 else 5 end)
  + (least(extract(epoch from (now() - i.created_at)) / 86400.0, 14) / 14.0 * 20)
  + (least((select count(*) from confirmations c where c.incident_id = i.id), 5) * 3)
  from incidents i
  where i.id = p_incident;
$$;

-- New report: make a complaint number, then either suggest a duplicate or open a new incident.
create or replace function reports_before_insert() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  dup     uuid;
  prev    uuid;
  new_inc uuid;
begin
  if new.complaint_no is null then
    new.complaint_no := generate_complaint_no();
  end if;
  if new.incident_id is not null then
    return new;  -- already linked (used by seed data)
  end if;

  dup := suggest_duplicate(new.location);
  if dup is not null then
    new.suggested_incident_id := dup;   -- an officer confirms the link or splits it
  else
    prev := find_recent_closed(new.location);
    insert into incidents (location, severity_citizen, repeat_of, is_sample)
    values (new.location, new.severity, prev, new.is_sample)
    returning id into new_inc;
    new.incident_id := new_inc;
  end if;
  return new;
end;
$$;
drop trigger if exists reports_bi on reports;
create trigger reports_bi before insert on reports
  for each row execute function reports_before_insert();

-- Log the first status of every new incident.
create or replace function incidents_after_insert() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into status_events (incident_id, actor_id, from_status, to_status)
  values (new.id, auth.uid(), null, new.status);
  return new;
end;
$$;
drop trigger if exists incidents_ai on incidents;
create trigger incidents_ai after insert on incidents
  for each row execute function incidents_after_insert();

-- IF TIME ALLOWS: two "not fixed" answers send a repaired/closed job back for review.
create or replace function after_fix_check() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  cur text;
  n   int;
begin
  select status into cur from incidents where id = new.incident_id;
  select count(*) into n from fix_checks where incident_id = new.incident_id and answer = 'not_fixed';
  if new.answer = 'not_fixed' and n >= 2 and cur in ('repaired', 'closed') then
    update incidents set status = 'review', closed_at = null, updated_at = now() where id = new.incident_id;
    insert into status_events (incident_id, actor_id, from_status, to_status, note)
    values (new.incident_id, null, cur, 'review', 'Sent back for review after citizen "not fixed" answers');
  end if;
  return new;
end;
$$;
drop trigger if exists fix_checks_ai on fix_checks;
create trigger fix_checks_ai after insert on fix_checks
  for each row execute function after_fix_check();

-- ---------------------------------------------------------------- officer actions
-- Incidents cannot be edited directly by anyone through the API (no write policies).
-- All changes go through these functions, which check the caller is an officer.

create or replace function set_status(p_incident uuid, p_to text, p_note text default null) returns incidents
language plpgsql security definer set search_path = public as $$
declare
  cur        incidents%rowtype;
  old_status text;
begin
  if not is_officer() then
    raise exception 'officers only';
  end if;
  select * into cur from incidents where id = p_incident for update;
  if not found then
    raise exception 'incident not found';
  end if;
  old_status := cur.status;

  if p_to = 'closed' and not exists (
       select 1 from repairs r where r.incident_id = p_incident and r.after_photo_path is not null) then
    raise exception 'closure requires an after-repair photo';
  end if;

  update incidents
     set status     = p_to,
         updated_at = now(),
         closed_at  = case when p_to = 'closed' then now() else null end
   where id = p_incident
   returning * into cur;

  insert into status_events (incident_id, actor_id, from_status, to_status, note)
  values (p_incident, auth.uid(), old_status, p_to, p_note);
  return cur;
end;
$$;

create or replace function assign_incident(p_incident uuid, p_officer uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_officer() then raise exception 'officers only'; end if;
  update incidents set assigned_to = p_officer, updated_at = now() where id = p_incident;
end;
$$;

create or replace function confirm_severity(p_incident uuid, p_severity text, p_road_type text default null) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_officer() then raise exception 'officers only'; end if;
  update incidents
     set severity_confirmed = p_severity,
         road_type = coalesce(p_road_type, road_type),
         updated_at = now()
   where id = p_incident;
end;
$$;

create or replace function record_after_photo(p_incident uuid, p_path text, p_notes text default null) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_officer() then raise exception 'officers only'; end if;
  insert into repairs (incident_id, completed_at, after_photo_path, notes)
  values (p_incident, now(), p_path, p_notes);
end;
$$;

-- Officer confirms a duplicate suggestion: attach the report to the existing incident.
create or replace function confirm_link(p_report uuid, p_incident uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_officer() then raise exception 'officers only'; end if;
  update reports set incident_id = p_incident, suggested_incident_id = null where id = p_report;
end;
$$;

-- Officer decides the suggestion is wrong: this is a separate pothole.
create or replace function split_report(p_report uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare
  r       reports%rowtype;
  prev    uuid;
  new_inc uuid;
begin
  if not is_officer() then raise exception 'officers only'; end if;
  select * into r from reports where id = p_report;
  if not found then raise exception 'report not found'; end if;
  prev := find_recent_closed(r.location);
  insert into incidents (location, severity_citizen, repeat_of, is_sample)
  values (r.location, r.severity, prev, r.is_sample)
  returning id into new_inc;
  update reports set incident_id = new_inc, suggested_incident_id = null where id = p_report;
  return new_inc;
end;
$$;

-- Anyone (even signed-out) can track a complaint by its number. Returns no personal data.
create or replace function track_complaint(p_no text)
returns table (complaint_no text, status text, created_at timestamptz, lat double precision, lng double precision)
language sql stable security definer set search_path = public as $$
  select r.complaint_no,
         coalesce(i.status, 'under_review'),
         r.created_at,
         ST_Y(r.location::geometry),
         ST_X(r.location::geometry)
  from reports r
  left join incidents i on i.id = r.incident_id
  where r.complaint_no = p_no;
$$;
grant execute on function track_complaint(text) to anon, authenticated;

-- ---------------------------------------------------------------- views

-- Open incidents, highest priority first (official dashboard queue).
create or replace view incident_queue as
select i.id,
       i.status,
       i.road_type,
       coalesce(i.severity_confirmed, i.severity_citizen) as severity,
       (i.severity_confirmed is not null)                  as severity_confirmed,
       ST_Y(i.location::geometry)                          as lat,
       ST_X(i.location::geometry)                          as lng,
       i.ward,
       i.created_at,
       floor(extract(epoch from (now() - i.created_at)) / 86400)::int as days_waiting,
       (select count(*) from confirmations c where c.incident_id = i.id) as confirmations,
       (i.repeat_of is not null)                           as is_repeat_failure,
       round(compute_priority(i.id), 1)                    as priority_score,
       i.is_sample
from incidents i
where i.status <> 'closed'
order by priority_score desc;

-- Chronic locations: 3 or more incidents within 20 m in the last 180 days.
create or replace view chronic_locations as
select a.id as incident_id, count(b.id) as incidents_nearby
from incidents a
join incidents b
  on ST_DWithin(a.location, b.location, 20)
 and b.created_at > now() - interval '180 days'
group by a.id
having count(b.id) >= 3;

-- Everything the public map needs (no personal data).
create or replace view public_incidents as
select i.id,
       i.status,
       coalesce(i.severity_confirmed, i.severity_citizen) as severity,
       ST_Y(i.location::geometry) as lat,
       ST_X(i.location::geometry) as lng,
       (i.repeat_of is not null)  as is_repeat_failure,
       (c.incident_id is not null) as is_chronic,
       i.created_at,
       i.is_sample
from incidents i
left join chronic_locations c on c.incident_id = i.id;

-- Status timeline without actor or internal notes.
create or replace view incident_timeline as
select incident_id, from_status, to_status, created_at from status_events;

-- Heatmap points (Leaflet.heat wants lat, lng, weight).
create or replace view heatmap_points as
select ST_Y(location::geometry) as lat, ST_X(location::geometry) as lng, 1 as weight
from incidents
where created_at > now() - interval '180 days';

-- IF TIME ALLOWS: ward statistics (needs incidents.ward filled in).
create or replace view ward_stats as
select coalesce(ward, 'unassigned') as ward,
       count(*)                                    as incidents,
       count(*) filter (where status = 'closed')   as closed,
       percentile_cont(0.5) within group (
         order by extract(epoch from (closed_at - created_at)) / 86400.0
       ) filter (where status = 'closed' and closed_at is not null) as median_days_to_close
from incidents
group by 1;

-- ---------------------------------------------------------------- row-level security

alter table profiles      enable row level security;
alter table incidents     enable row level security;
alter table reports       enable row level security;
alter table confirmations enable row level security;
alter table repairs       enable row level security;
alter table status_events enable row level security;
alter table fix_checks    enable row level security;

drop policy if exists "profile: own or officer" on profiles;
create policy "profile: own or officer" on profiles
  for select to authenticated using (id = auth.uid() or is_officer());

-- Incident locations are public map data. There are NO insert/update/delete policies,
-- so citizens cannot change a status or any incident field through the API.
drop policy if exists "incidents: public read" on incidents;
create policy "incidents: public read" on incidents for select using (true);

drop policy if exists "reports: insert own" on reports;
create policy "reports: insert own" on reports
  for insert to authenticated with check (reporter_id = auth.uid());
drop policy if exists "reports: read own or officer" on reports;
create policy "reports: read own or officer" on reports
  for select to authenticated using (reporter_id = auth.uid() or is_officer());

drop policy if exists "confirmations: insert own" on confirmations;
create policy "confirmations: insert own" on confirmations
  for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "confirmations: read own or officer" on confirmations;
create policy "confirmations: read own or officer" on confirmations
  for select to authenticated using (user_id = auth.uid() or is_officer());

drop policy if exists "repairs: officers only" on repairs;
create policy "repairs: officers only" on repairs
  for all to authenticated using (is_officer()) with check (is_officer());

drop policy if exists "status_events: officers read" on status_events;
create policy "status_events: officers read" on status_events
  for select to authenticated using (is_officer());

drop policy if exists "fix_checks: insert own" on fix_checks;
create policy "fix_checks: insert own" on fix_checks
  for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "fix_checks: read own or officer" on fix_checks;
create policy "fix_checks: read own or officer" on fix_checks
  for select to authenticated using (user_id = auth.uid() or is_officer());

-- ---------------------------------------------------------------- photo storage (private bucket)
-- Convention: photos/<user-id>/<random>.jpg ; officers can read everything.

insert into storage.buckets (id, name, public)
values ('photos', 'photos', false)
on conflict (id) do nothing;

drop policy if exists "photos: upload to own folder" on storage.objects;
create policy "photos: upload to own folder" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'photos' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "photos: read own or officer" on storage.objects;
create policy "photos: read own or officer" on storage.objects
  for select to authenticated
  using (bucket_id = 'photos' and ((storage.foldername(name))[1] = auth.uid()::text or is_officer()));
